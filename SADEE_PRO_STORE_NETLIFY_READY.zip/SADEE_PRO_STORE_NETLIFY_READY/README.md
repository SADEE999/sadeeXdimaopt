# SADEE PRO STORE — Netlify + GitHub package

This package is arranged for a GitHub repository where `index.html`, `store.js`, `styles.css`, `config.js`, `admin/`, `supabase/`, and `netlify/` are at the repository root.

## Netlify deployment

1. Connect the GitHub repository `SADEE999/sadee-pro-store` to the Netlify project.
2. Keep the Netlify base directory empty and the build command empty. `netlify.toml` sets the publish directory to `.` and Functions directory to `netlify/functions`.
3. Trigger a deploy from the `main` branch. Confirm the deploy is **Published** and that Netlify lists the six functions in `netlify/functions`.
4. Do not deploy this as a drag-and-drop static-only site; checkout, order management, promo validation and reviews use Netlify Functions.

## Supabase setup

In the Supabase SQL Editor for the project configured in `config.js`, run these files in order:

1. `supabase/schema.sql`
2. `supabase/orders-schema.sql`

Check that both scripts complete without errors. Confirm the `product-images` bucket exists and is public-read only. Image uploads are performed server-side.

## Netlify environment variables

Add these in Netlify → Site configuration → Environment variables, then redeploy:

- `SUPABASE_URL` — the Supabase project URL.
- `SUPABASE_SERVICE_ROLE_KEY` — service-role key; server-side only.
- `STORE_ADMIN_SECRET` — a long, private admin secret that you create and keep private.
- `RESEND_API_KEY` — optional; needed for automatic order email.
- `STORE_FROM_EMAIL` — optional; a sender address verified with Resend.

Never put `SUPABASE_SERVICE_ROLE_KEY`, `STORE_ADMIN_SECRET`, or Resend secrets in `config.js`, browser JavaScript, or GitHub. `.env.example` contains placeholders only.

## Public browser configuration

`config.js` contains the public Supabase URL and publishable/anon key, plus the store contact/payment display settings. Confirm the WhatsApp and eZ Cash numbers and support email are correct before accepting customer orders. Do not replace the public key with a service-role key.

## Payment and license flow

This build uses manual eZ Cash verification; it does not automatically query eZ Cash. Check the actual incoming transaction in the official account before marking an order as verified. A license key is generated only after the admin verifies the payment. Test with a small test order before launch.

## Before announcing the store

- Test product listing, search, categories, wishlist and product details.
- Test admin product add/edit/delete and image upload.
- Test valid, expired and invalid promo codes.
- Submit a test order and confirm it remains pending until verified.
- Test reject and verify flows, stock changes, and My Orders lookup with the matching email.
- Confirm no key is shown for pending or rejected orders.
- If email delivery is enabled, test Resend with a verified sender.
- Test the site on mobile and confirm the PWA shell loads over HTTPS.

## Important limitations

This ZIP has been syntax-checked locally, but it has not been deployed to your Netlify account and cannot verify your live Supabase database, secrets, payment receipt, email provider, or domain. Those account-side setup and live tests must be completed before taking real orders.
